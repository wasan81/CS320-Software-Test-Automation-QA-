package myAppContact;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.ValidationException;

public class TaskService {
	
	private static Map<String, Task> TaskDatabase = new HashMap<>();
	public static Map<String, Task> TaskDatabase(){
		return TaskDatabase;
	}
	
	public static boolean add(Task task) {
		if(TaskDatabase.containsKey(Task.getId())){
			return false;
		}
		TaskDatabase.putIfAbsent(Task.getId(), task);
		return true;
	}
	
	public static  boolean delete(String id) {
		if(TaskDatabase.remove(id)== null) {
			return false;
		}
		return true;
	}
	public static boolean update(String id, Task updated)throws ValidationException {
		Task existing = TaskDatabase.get(id);
		if(existing == null) return false;
		existing.setName(updated.getName());
		existing.setDescription(updated.getDescription());
		
		return true;
	}

}
