package myAppcontactTest;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import javax.xml.bind.ValidationException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import myAppContact.Task;

class TaskTest {
	private Task validTask;
	
	@BeforeEach
	void setUp ()throws ValidationException{
		validTask =  new Task("1234567890", "Jake", "Task Description");
	}

    @Test
    void testValidTask() {
       
        assertEquals("1234567890", Task.getId());
        assertEquals("Jake", validTask.getName());
        assertEquals("Task Description", validTask.getDescription());
    }
    @Test
    void testInvalidId() {
    	assertThrows(ValidationException.class, ( )->{
    		new Task("C1234567890", "Jake", "Task Description");
    	});
    }
    @Test
    void testInvalidName() {
    	// test first name null
    	assertThrows(ValidationException.class, ( )->{
    		new Task("1234567890", null , "Task Description");
    	});
    
    	// test first name longer than 10
    	assertThrows(ValidationException.class, ( )->{
    		new Task("1234567890", "ChirstopherChirstopher" , "Task Description");
    	});
    }
    @Test
    void testInvalidDescription() {
    	assertThrows(ValidationException.class, ( )->{
    		new Task("1234567890", "Jake" , "TaskDescriptionShouldBeMoreThanTwentyCharachersLong");
    	});
    }
    @Test
    void testSetter() {
    	validTask.setId("C1234567890");
    	validTask.setName("Bob");
    	validTask.setDescription("Desccription");
    }
    
}
   
    

  
