package myAppcontactTest;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import javax.xml.bind.ValidationException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import myAppContact.Task;
import myAppContact.TaskService;

public class TaskServiceTest {
	private Task task;

    @BeforeEach
    void setUp()throws ValidationException{
    	TaskService.TaskDatabase().clear();
    	task = new Task("12345", "Bob", "TaskDescription");
    }

    @Test
    void testAddTask()  {
        assertTrue(TaskService.add(task));
        assertTrue(TaskService.TaskDatabase().containsKey("12345"));
        assertFalse(TaskService.add(task));
       
    }

    @Test
    void testDeleteTask(){
      
        assertTrue(TaskService.add(task));
        assertTrue(TaskService.delete("12345"));
        assertFalse(TaskService.TaskDatabase().containsKey("12345"));
        assertFalse(TaskService.delete("54321"));
    }

    @Test
    void testUpdate()throws ValidationException{
        assertTrue(TaskService.add(task));
        Task updated = new Task("12345", "Jake", "Description");
        assertTrue(TaskService.update("12345", updated));
        Task storedTask = TaskService.TaskDatabase().get("12345");
        assertTrue(storedTask.getName().equals("Jake"));
        assertTrue(storedTask.getDescription().equals("Description"));
    }
}
