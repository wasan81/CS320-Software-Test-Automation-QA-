package myAppContact;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	    private Map<String, Appointment> appointments = new HashMap<>();

	    // Add an appointment
	    public void addAppointment(Appointment appointment) {
	        if (appointments.containsKey(appointment.getAppointmentID())) {
	            throw new IllegalArgumentException("Appointment ID already exists");
	        }
	        appointments.put(appointment.getAppointmentID(), appointment);
	    }

	    // Delete an appointment by ID
	    public void deleteAppointment(String appointmentID) {
	        if (!appointments.containsKey(appointmentID)) {
	            throw new IllegalArgumentException("Appointment ID not found");
	        }
	        appointments.remove(appointmentID);
	    }

	    // Retrieve an appointment by ID (optional for testing purposes)
	    public Appointment getAppointment(String appointmentID) {
	        return appointments.get(appointmentID);
	    }
}


