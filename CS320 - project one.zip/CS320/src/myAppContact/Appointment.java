package myAppContact;


import java.util.Date;

public class Appointment {
	
	    private String appointmentID;
	    private  Date appointmentDate;
	    private  String description;
	 

	    
	    public Appointment(String appointmentID, Date appointmentDate, String description) {
	    	
	        if (appointmentID == null || appointmentID.length() > 10 || appointmentID.length() < 1) {
	            throw new IllegalArgumentException("Invalid appointment ID");
	        }
	        if (appointmentDate == null || appointmentDate.before(new Date())) {
	            throw new IllegalArgumentException("Invalid appointment date");
	        }
	        if (description == null || description.length() > 50 || description.length() < 1) {
	            throw new IllegalArgumentException("Invalid description");
	        }

	        this.appointmentID = appointmentID;
	        this.appointmentDate = appointmentDate;
	        this.description = description;
	    }

	

		// Getters
	    public String getAppointmentID() {
	        return appointmentID;
	    }

	    public Date getAppointmentDate() {
	        return new Date(appointmentDate.getTime()); 
	    }

	    public String getDescription() {
	        return description;
	    }
	    public void updateAppointmentDate(Date newDate) {
	        if (newDate == null || newDate.before(new Date())) {
	            throw new IllegalArgumentException("Invalid appointment date");
	        }
	        this.appointmentDate = newDate;
	    }

	    public void updateDescription(String newDescription) {
	        if (newDescription == null || newDescription.length() > 50 || newDescription.length() < 1) {
	            throw new IllegalArgumentException("Invalid description");
	        }
	        this.description = newDescription;
	    }


}
