package myAppContact;

import javax.xml.bind.ValidationException;

public class contact {
    private String contactID; // Cannot be updated
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    // Constructor
    public contact(String contactID, String firstName, String lastName, String phone, String address) 
    	throws ValidationException {
        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;

        validate(); 
    }

    // Getters
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // Setters
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Validation method
    public void validate() throws ValidationException {
        if (contactID == null || contactID.length() > 10) {
            throw new ValidationException("Invalid Contact ID");
        }
        if (firstName == null || firstName.length() > 10) {
            throw new ValidationException("Invalid First Name");
        }
        if (lastName == null || lastName.length() > 10) {
            throw new ValidationException("Invalid Last Name");
        }
        if (phone == null || phone.length() != 10 ) {
            throw new ValidationException("Invalid Phone Number");
        }
        if (address == null || address.length() > 30) {
            throw new ValidationException("Invalid Address");
        }
    }
}
