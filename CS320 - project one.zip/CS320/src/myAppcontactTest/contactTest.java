package myAppcontactTest;

import static org.junit.jupiter.api.Assertions.*;

import javax.xml.bind.ValidationException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import myAppContact.contact;

class contactTest {

    private contact validContact;

    @BeforeEach
    void setUp() throws ValidationException {
        
        validContact = new contact("C123", "Mike", "Joe", "1234567890", "123 Main St");
    }

    @Test
    void testValidContact() {
        // Test to ensure that the valid contact's fields are correctly set
        assertEquals("C123", validContact.getContactID());
        assertEquals("Mike", validContact.getFirstName());
        assertEquals("Joe", validContact.getLastName());
        assertEquals("1234567890", validContact.getPhone());
        assertEquals("123 Main St", validContact.getAddress());
    }

    @Test
    void testInvalidContactID() {
        // Test for invalid Contact ID (longer than 10 characters)
        assertThrows(ValidationException.class, () -> {
            new contact("C12345678901", "Mike", "Joe", "1234567890", "123 Main St");
        });
    }

    @Test
     void testInvalidFirstName() {
        // Test with a null first name
        assertThrows(ValidationException.class, () -> {
            new contact("C123", null, "Joe", "1234567890", "123 Main St");
        }, "First name is null; should throw ValidationException.");

        // Test with a first name longer than 10 characters
        assertThrows(ValidationException.class, () -> {
            new contact("C123", " Christopher", "Joe", "1234567890", "123 Main St");
        }, "First name exceeds 10 characters; should throw ValidationException.");
    }

    @Test
    void testInvalidLastName() {
        // Test for invalid Last Name (longer than 10 characters)
        assertThrows(ValidationException.class, () -> {
            new contact("C123", "John", "DoeSuperLongName", "1234567890", "123 Main St");
        });
    }

    @Test
    void testInvalidPhone() {
        // Test for invalid Phone (not exactly 10 digits)
        assertThrows(ValidationException.class, () -> {
            new contact("C123", "John", "Doe", "12345", "123 Main St");
        });
    }

    @Test
    void testInvalidPhoneFormat() {
        // Test for invalid Phone (contains non-numeric characters)
        assertThrows(ValidationException.class, () -> {
            new contact("C123", "John", "Doe", "12345abcd", "123 Main St");
        });
    }

    @Test
    void testInvalidAddress() {
        // Test for invalid Address (longer than 30 characters)
        assertThrows(ValidationException.class, () -> {
            new contact("C123", "John", "Doe", "1234567890", "123 Main Street, Suite 100, City, Country");
        });
    }

    @Test
    void testSetters() {
        // Test setters for modifying the contact's details
        validContact.setFirstName("Jane");
        validContact.setLastName("Smith");
        validContact.setPhone("0987654321");
        validContact.setAddress("555 Ash St");

        assertEquals("Jane", validContact.getFirstName());
        assertEquals("Smith", validContact.getLastName());
        assertEquals("0987654321", validContact.getPhone());
        assertEquals("555 Ash St", validContact.getAddress());
    }
}