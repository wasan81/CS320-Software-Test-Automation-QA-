package myAppcontactTest;

import static org.junit.jupiter.api.Assertions.*;

import javax.xml.bind.ValidationException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import myAppContact.contact;
import myAppContact.contactService;

public class contactServiceTest {

    private contact contact1;
    

    @BeforeEach
    void setUp() throws ValidationException {
        
        contactService.CONTACT_DATABASE().clear();

       // example two contacts 
        contact1 = new contact("C123", "Mike", "Joe", "1234567890", "123 Main St");
        
    }


    @Test
    void testAddContact() {
        assertTrue(contactService.add(contact1)); //add contact 1
        assertTrue(contactService.CONTACT_DATABASE().containsKey("C123"));
        
        assertFalse(contactService.add(contact1)); 
    }

    @Test
    void testDeleteContact() {
        contactService.add(contact1);
        assertTrue(contactService.delete("C123")); 
        assertFalse(contactService.CONTACT_DATABASE().containsKey("C123"));

        assertFalse(contactService.delete("C759")); 
    }

    @Test
    void testUpdateContact() throws ValidationException {
        contactService.add(contact1);
        contact updatedContact = new contact("C123", "Johnathan", "Doe", "1122334455", "789 Ash St");

        assertTrue(contactService.update("C123", updatedContact)); 
        contact retrievedContact = contactService.CONTACT_DATABASE().get("C123");
        assertEquals("Johnathan", retrievedContact.getFirstName(),"First name should be updated to 'Johnathan'.");
        assertEquals("1122334455", retrievedContact.getPhone());
        assertEquals("789 Ash St", retrievedContact.getAddress());
    }
    @Test
    void testUpdateNonExistentContact() throws ValidationException {
        contact updatedContact = new contact("C789", "Alice", "Wonder", "6677889900", "111 Pine St");
        assertFalse(contactService.update("C789", updatedContact)); 
    }
}
