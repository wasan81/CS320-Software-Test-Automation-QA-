package myAppContact;

import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.ValidationException;

import myAppContact.contact;

public class contactService {
	
	   private static final Map<String, contact> contactDatabase = new HashMap<>();

	    // Method to return the contact database
	    public static Map<String, contact> CONTACT_DATABASE() {
	        return contactDatabase;
	    }
	
	public static boolean add(contact contact) {
		if (contactDatabase.containsKey(contact.getContactID())) {
            System.out.println("Error: Contact ID already exists.");
            return false;
        }
        contactDatabase.putIfAbsent(contact.getContactID(), contact);
        return true;
    }
	
	public static boolean delete(String id) {
        if (contactDatabase.remove(id) == null) {
            System.out.println("Error: No contact with ID " + id);
            return false;
        }
        return true;
    }
	
	 public static boolean update(String id, contact updated) throws ValidationException {
	        contact existing = contactDatabase.get(id);
	        if (existing == null) {
	            System.out.println("Error: Contact with ID " + id + " does not exist.");
	            return false;
	        }
	        existing.setFirstName(updated.getFirstName());
	        existing.setLastName(updated.getLastName());
	        existing.setPhone(updated.getPhone());
	        existing.setAddress(updated.getAddress());
	        existing.validate();
	        return true;
	    }

	
	  
	}

	
	



