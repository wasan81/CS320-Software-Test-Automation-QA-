package myAppcontactTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import myAppContact.Appointment;

import java.util.Date;
import java.util.Calendar;

class AppointmentTest {
    private Appointment validAppointment;

    
    private Date getDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); 
        return calendar.getTime(); 
    }

    @BeforeEach
    void setUp() {
        validAppointment = new Appointment("1234567890", getDate(), "Valid description");
    }

    @Test
    void testValidAppointment() {
        assertEquals("1234567890", validAppointment.getAppointmentID());
        assertNotNull(validAppointment.getAppointmentDate());
        assertEquals("Valid description", validAppointment.getDescription());
    }

    @Test
    void testInvalidAppointmentID() {
        // ID too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getDate(), "Valid description");
        });

        // Null ID
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getDate(), "Valid description");
        });
    }

    @Test
    void testInvalidAppointmentDate() {
        // Date in the past
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in the past
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Valid description");
        });

        // Null date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", null, "Valid description");
        });
    }

    @Test
    void testInvalidDescription() {
        // Description too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", getDate(), "This description is more than fifty characters long.");
        });

        // Null description
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", getDate(), null);
        });
    }

    @Test
    void testUpdateMethods() {
        // Update date to a new valid future date
        Date newDate = getDate();
        validAppointment.updateAppointmentDate(newDate);
        assertEquals(newDate, validAppointment.getAppointmentDate());

        // Update description to a new valid description
        validAppointment.updateDescription("Updated description");
        assertEquals("Updated description", validAppointment.getDescription());

        // Test invalid updates
        assertThrows(IllegalArgumentException.class, () -> validAppointment.updateAppointmentDate(new Date(System.currentTimeMillis() - 86400000))); // Past date
        assertThrows(IllegalArgumentException.class, () -> validAppointment.updateDescription(null));
        assertThrows(IllegalArgumentException.class, () -> validAppointment.updateDescription("This description is more than fifty characters long."));
    }
}


