package myAppcontactTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import myAppContact.Appointment;
import myAppContact.AppointmentService;

class AppointmentServiceTest {
    private AppointmentService appointmentService;
    private Appointment validAppointment;
    private Appointment duplicateAppointment;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
        validAppointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "Valid description");
        duplicateAppointment = new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "Duplicate description");
    }

    @Test
    void testAddAppointment() {
    
        appointmentService.addAppointment(validAppointment);
        assertEquals(validAppointment, appointmentService.getAppointment("1234567890"));
    }

    @Test
    void testAddDuplicateAppointment() {
       
        appointmentService.addAppointment(validAppointment);
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(duplicateAppointment);
        });
    }

    @Test
    void testDeleteAppointment() {
        // Adding a valid appointment
        appointmentService.addAppointment(validAppointment);
        
        // Deleting the appointment
        appointmentService.deleteAppointment("1234567890");
        
        // Ensuring the appointment is deleted
        assertNull(appointmentService.getAppointment("1234567890"));
    }

    @Test
    void testDeleteNonExistingAppointment() {
        // Trying to delete a non-existing appointment should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("nonExistingID");
        });
    }

}
