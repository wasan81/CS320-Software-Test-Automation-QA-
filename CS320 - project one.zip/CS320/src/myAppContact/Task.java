package myAppContact;

import javax.xml.bind.ValidationException;

public class Task {
	private static String id;
	private static String name;
	private static String description;
	
	//Constructor
	public Task(String id, String name, String description) throws ValidationException {
		
	Task.id = id;
	Task.name=name;
	Task.description=description;
	validate();
	}

	//Getters
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public static String getId() {
		return id;
	}
	
	// Setter
	public void setId(String id) {
		Task.id= id;
	}
	public void setName(String name) {
		Task.name= name;
	}
	public void setDescription(String description) {
		Task.description= description;
	}
	// validation 
	public void validate()throws ValidationException{
		if( name == null|| name.trim().length() <1 || name.length()>20) {
			throw new ValidationException(" name is bad");
		}
		if( description == null|| description.trim().length() <1 || description.length()>50) {
			throw new ValidationException(" description is bad");
		}
		if(id == null|| id.trim().length() <1 || id.length()>10) {
			throw new ValidationException(" id is bad");
		}
	}
}
	
	
	
	
	
	

	
	
	


	


	
	


